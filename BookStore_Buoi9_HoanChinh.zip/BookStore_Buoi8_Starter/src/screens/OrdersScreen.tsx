import React, { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { RootScreenProps } from "../navigation/types";
import { useAuth } from "../store/hooks";
import { getOrdersByUser } from "../services/orderService";
import { getErrorMessage } from "../api/client";
import { Order } from "../types";
import { colors, formatPrice } from "../theme";
import { EmptyState } from "../components/EmptyState";
import { LoadingView } from "../components/LoadingView";
import { ErrorView } from "../components/ErrorView";

const statusText: Record<string,string> = { pending:"Chờ xác nhận", shipping:"Đang giao", completed:"Hoàn thành", cancelled:"Đã hủy" };
export function OrdersScreen(_props: RootScreenProps<"Orders">) {
 const { user } = useAuth(); const [orders,setOrders]=useState<Order[]>([]); const [loading,setLoading]=useState(true); const [refreshing,setRefreshing]=useState(false); const [error,setError]=useState<string|null>(null); const [openId,setOpenId]=useState<number|null>(null);
 const load=useCallback(async()=>{ if(!user)return; setError(null); try { const data=await getOrdersByUser(user.id); setOrders([...data].sort((a,b)=>b.createdAt.localeCompare(a.createdAt))); } catch(e){setError(getErrorMessage(e));} finally{setLoading(false);setRefreshing(false);} },[user]);
 useEffect(()=>{load();},[load]);
 if(loading)return <LoadingView label="Đang tải đơn hàng…"/>;
 if(error)return <ErrorView message={error} onRetry={load}/>;
 return <FlatList style={s.page} contentContainerStyle={s.list} data={orders} keyExtractor={o=>String(o.id)} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>{setRefreshing(true);load();}}/>} ListEmptyComponent={<EmptyState emoji="🧾" title="Bạn chưa có đơn hàng nào" message="Các đơn hàng sau khi đặt sẽ xuất hiện ở đây."/>} renderItem={({item:o})=>{const opened=openId===o.id;return <View style={s.card}><Pressable onPress={()=>setOpenId(opened?null:o.id)}><View style={s.row}><Text style={s.order}>Đơn hàng #{o.id}</Text><Text style={s.status}>{statusText[o.status]??o.status}</Text></View><Text style={s.muted}>{new Date(o.createdAt).toLocaleString("vi-VN")}</Text><Text style={s.total}>{formatPrice(o.total)}</Text><Text style={s.link}>{opened?"Thu gọn ▲":"Xem chi tiết ▼"}</Text></Pressable>{opened&&<View style={s.details}><Text style={s.subhead}>Sản phẩm</Text>{o.items.map((i,idx)=><Text key={`${i.bookId}-${idx}`} style={s.detailText}>• {i.title} × {i.quantity} — {formatPrice(i.price*i.quantity)}</Text>)}<Text style={s.subhead}>Địa chỉ giao hàng</Text><Text style={s.detailText}>{o.address.name} · {o.address.phone}</Text><Text style={s.detailText}>{o.address.address}</Text><Text style={s.detailText}>Thanh toán: {o.paymentMethod==="cod"?"COD":"Chuyển khoản"}</Text></View>}</View>}}/>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.bg},list:{padding:14,gap:12,flexGrow:1},card:{backgroundColor:"white",padding:15,borderRadius:14,borderWidth:1,borderColor:colors.line},row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",gap:8},order:{fontSize:16,fontWeight:"800",color:colors.text},status:{color:colors.indigo,fontWeight:"700"},muted:{color:colors.muted,marginTop:5,fontSize:12},total:{fontSize:18,fontWeight:"900",color:colors.indigo,marginTop:8},link:{color:colors.indigo,fontWeight:"700",marginTop:8},details:{borderTopWidth:1,borderColor:colors.line,marginTop:12,paddingTop:10,gap:5},subhead:{fontWeight:"800",color:colors.text,marginTop:5},detailText:{color:colors.muted,lineHeight:21}});
