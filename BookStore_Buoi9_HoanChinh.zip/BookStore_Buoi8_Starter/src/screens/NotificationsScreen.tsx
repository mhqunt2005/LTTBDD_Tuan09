import React, { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { RootScreenProps } from "../navigation/types";
import { useAuth } from "../store/hooks";
import { getNotifications, markAsRead } from "../services/notificationService";
import { getErrorMessage } from "../api/client";
import { AppNotification } from "../types";
import { colors } from "../theme";
import { EmptyState } from "../components/EmptyState";
import { LoadingView } from "../components/LoadingView";
import { ErrorView } from "../components/ErrorView";
export function NotificationsScreen({navigation}:RootScreenProps<"Notifications">){
 const {user}=useAuth(); const [data,setData]=useState<AppNotification[]>([]); const [loading,setLoading]=useState(true); const [refreshing,setRefreshing]=useState(false); const [error,setError]=useState<string|null>(null);
 const load=useCallback(async()=>{if(!user)return;setError(null);try{setData(await getNotifications(user.id));}catch(e){setError(getErrorMessage(e));}finally{setLoading(false);setRefreshing(false);}},[user]); useEffect(()=>{load();},[load]);
 const open=async(n:AppNotification)=>{if(!n.read){setData(prev=>prev.map(x=>x.id===n.id?{...x,read:true}:x));markAsRead(n.id).catch(()=>setData(prev=>prev.map(x=>x.id===n.id?{...x,read:false}:x)));}if(n.target?.screen==="Orders")navigation.navigate("Orders");else if(n.target?.screen==="BookDetail"&&n.target.bookId)navigation.navigate("BookDetail",{bookId:n.target.bookId});};
 if(loading)return <LoadingView label="Đang tải thông báo…"/>;if(error)return <ErrorView message={error} onRetry={load}/>;
 return <FlatList style={s.page} contentContainerStyle={s.list} data={data} keyExtractor={n=>String(n.id)} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>{setRefreshing(true);load();}}/>} ListEmptyComponent={<EmptyState emoji="🔔" title="Chưa có thông báo nào"/>} renderItem={({item})=><Pressable onPress={()=>open(item)} style={[s.card,!item.read&&s.unread]}><View style={s.row}><Text style={s.title}>{item.title}</Text>{!item.read&&<View style={s.dot}/>}</View><Text style={s.body}>{item.body}</Text><Text style={s.date}>{new Date(item.createdAt).toLocaleString("vi-VN")}</Text></Pressable>}/>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.bg},list:{padding:14,gap:10,flexGrow:1},card:{backgroundColor:"white",padding:14,borderRadius:12,borderWidth:1,borderColor:colors.line},unread:{backgroundColor:"#EAF2FF",borderColor:"#BFDBFE"},row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",gap:8},title:{fontWeight:"800",color:colors.text,flex:1},dot:{width:9,height:9,borderRadius:9,backgroundColor:colors.danger},body:{color:colors.muted,marginTop:6,lineHeight:20},date:{color:colors.muted,fontSize:11,marginTop:8}});
