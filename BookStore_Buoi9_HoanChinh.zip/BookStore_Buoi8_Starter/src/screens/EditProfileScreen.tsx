import React, { useState } from "react";
import { ScrollView, StyleSheet, Text } from "react-native";
import { RootScreenProps } from "../navigation/types";
import { useAuth } from "../store/hooks";
import { FormField } from "../components/FormField";
import { PrimaryButton } from "../components/PrimaryButton";
import { updateProfile } from "../services/userService";
import { getErrorMessage } from "../api/client";
import { validatePhone, validateRequired } from "../utils/validators";
import { showMessage } from "../utils/dialog";
import { colors } from "../theme";
export function EditProfileScreen({navigation}:RootScreenProps<"EditProfile">){
 const {user,patchUser}=useAuth(); const [name,setName]=useState(user?.name??""); const [phone,setPhone]=useState(user?.phone??""); const [touched,setTouched]=useState(false); const [loading,setLoading]=useState(false); const [error,setError]=useState<string|null>(null);
 const nameError=touched?validateRequired("họ tên")(name):null; const phoneError=touched?validatePhone(phone):null;
 const save=async()=>{setTouched(true);if(!user||validateRequired("họ tên")(name)||validatePhone(phone))return;setLoading(true);setError(null);try{const updated=await updateProfile(user.id,{name:name.trim(),phone:phone.trim()});patchUser(updated);showMessage("Đã lưu","Thông tin hồ sơ đã được cập nhật.",()=>navigation.goBack());}catch(e){setError(getErrorMessage(e));}finally{setLoading(false);}};
 return <ScrollView style={s.page} contentContainerStyle={s.content}><Text style={s.heading}>Thông tin cá nhân</Text><FormField label="Họ và tên" value={name} onChangeText={setName} error={nameError} placeholder="Nhập họ tên"/><FormField label="Số điện thoại" value={phone} onChangeText={setPhone} error={phoneError} keyboardType="phone-pad" placeholder="0901234567"/><Text style={s.email}>Email: {user?.email??""}</Text>{error?<Text style={s.error}>{error}</Text>:null}<PrimaryButton title="Lưu thay đổi" onPress={save} loading={loading}/></ScrollView>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.bg},content:{padding:16,gap:16},heading:{fontSize:20,fontWeight:"800",color:colors.text},email:{color:colors.muted},error:{color:colors.danger}});
