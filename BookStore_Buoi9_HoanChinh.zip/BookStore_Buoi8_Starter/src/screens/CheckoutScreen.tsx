import React, { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { RootScreenProps } from "../navigation/types";
import { useAuth, useCart } from "../store/hooks";
import { colors, formatPrice } from "../theme";
import { FormField } from "../components/FormField";
import { PrimaryButton } from "../components/PrimaryButton";
import { createOrder } from "../services/orderService";
import { getErrorMessage } from "../api/client";
import { PaymentMethod } from "../types";
import { showMessage } from "../utils/dialog";
import { validatePhone, validateRequired } from "../utils/validators";

export function CheckoutScreen({ navigation, route }: RootScreenProps<"Checkout">) {
  const { user, isLoggedIn } = useAuth();
  const { items, clear } = useCart();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [address, setAddress] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("cod");
  const [touched, setTouched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const nameError = touched ? validateRequired("họ tên")(name) : null;
  const phoneError = touched ? validatePhone(phone) : null;
  const addressError = touched ? validateRequired("địa chỉ giao hàng")(address) : null;
  const valid = !validateRequired("họ tên")(name) && !validatePhone(phone) && !validateRequired("địa chỉ giao hàng")(address) && items.length > 0;

  useEffect(() => {
    if (!isLoggedIn) navigation.replace("Login", { redirectTo: "Checkout", total: route.params.total });
  }, [isLoggedIn, navigation, route.params.total]);

  const submit = async () => {
    setTouched(true);
    if (!valid || !user) return;
    setLoading(true); setSubmitError(null);
    try {
      await createOrder({
        userId: user.id,
        items: items.map((i) => ({ bookId: i.bookId, title: i.title, price: i.price, quantity: i.quantity })),
        total: route.params.total,
        address: { name: name.trim(), phone: phone.trim(), address: address.trim() },
        paymentMethod: payment,
      });
      clear();
      showMessage("Đặt hàng thành công 🎉", "Cảm ơn bạn đã mua sắm tại BookStore!", () => navigation.navigate("Tabs", { screen: "Home" }));
    } catch (e) { setSubmitError(getErrorMessage(e)); }
    finally { setLoading(false); }
  };

  if (!isLoggedIn) return null;
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <Text style={s.heading}>Thông tin giao hàng</Text>
    <FormField label="Họ và tên người nhận" value={name} onChangeText={setName} error={nameError} placeholder="Nguyễn Văn A" />
    <FormField label="Số điện thoại" value={phone} onChangeText={setPhone} error={phoneError} keyboardType="phone-pad" placeholder="0901234567" />
    <FormField label="Địa chỉ giao hàng" value={address} onChangeText={setAddress} error={addressError} placeholder="Số nhà, đường, phường, quận, tỉnh/thành" multiline />
    <Text style={s.heading}>Phương thức thanh toán</Text>
    <Text onPress={() => setPayment("cod")} style={[s.option, payment === "cod" && s.selected]}> {payment === "cod" ? "🔘" : "⚪"} Thanh toán khi nhận hàng (COD)</Text>
    <Text onPress={() => setPayment("bank")} style={[s.option, payment === "bank" && s.selected]}> {payment === "bank" ? "🔘" : "⚪"} Chuyển khoản ngân hàng</Text>
    <View style={s.summary}><Text style={s.label}>Tổng thanh toán</Text><Text style={s.total}>{formatPrice(route.params.total)}</Text></View>
    {submitError ? <Text style={s.error}>{submitError}</Text> : null}
    <PrimaryButton title="Xác nhận đặt hàng" onPress={submit} loading={loading} disabled={items.length === 0} />
  </ScrollView>;
}
const s = StyleSheet.create({ page:{flex:1,backgroundColor:colors.bg},content:{padding:16,gap:14},heading:{fontSize:18,fontWeight:"800",color:colors.text,marginTop:4},option:{backgroundColor:"white",padding:14,borderRadius:12,color:colors.text,borderWidth:1,borderColor:colors.line},selected:{borderColor:colors.indigo,backgroundColor:"#EEF2FF"},summary:{backgroundColor:"white",padding:16,borderRadius:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},label:{color:colors.muted},total:{fontSize:20,fontWeight:"900",color:colors.indigo},error:{color:colors.danger} });
